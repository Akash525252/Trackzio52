/*
  All page content lives here. Edit this file to change text, platforms,
  experts or reviews — the page rebuilds itself from it.
  Images go in assets/images/ with the exact file names used below
  (see IMAGES.md). Missing images show a labelled grey placeholder.
*/

window.SITE = {
  hero: {
    tag: "For collectors and enthusiasts",
    titleStart: "Identify, collect and trade",
    rotatingWords: ["coins", "banknotes", "rocks", "antiques", "what you love"],
    subtitle:
      "Trackzio builds end-to-end platforms for collectors and enthusiasts. Scan an item, learn its story, build your collection, ask an expert and trade with trusted sellers, all in one place.",
    primaryCta: { label: "Explore our platforms", href: "#platforms" },
    secondaryCta: { label: "Partner with us", href: "https://trackzio.com/partners" },
    images: ["hero-phone-1.png", "hero-phone-2.png", "hero-phone-3.png"]
  },

  stats: [
    { value: 400, suffix: "K+", label: "Downloads" },
    { value: 50, suffix: "K+", label: "Active users" },
    { value: 4.3, suffix: "+", label: "Average rating", decimals: 1 },
    { value: 20, suffix: "+", label: "Experts" },
    { value: 1000, suffix: "+", label: "Scans a day" }
  ],

  platforms: [
    { name: "Coinzy", group: "collectors", tagline: "Every coin has a story.", line: "Identify, value, collect and trade coins, all in one place.", logo: "logo-coinzy.png", image: "platform-coinzy.png", href: "https://trackzio.com/coinzy" },
    { name: "Banknote", group: "collectors", tagline: "Paper with a past.", line: "Identify, value, collect and trade banknotes and paper money.", logo: "logo-banknote.png", image: "platform-banknote.png", href: "#" },
    { name: "Rockzy", group: "collectors", tagline: "Millions of years in your palm.", line: "Identify, collect and trade rocks, minerals, crystals and gems.", logo: "logo-rockzy.png", image: "platform-rockzy.png", href: "#" },
    { name: "Antiqzy", group: "collectors", tagline: "Old things, new stories.", line: "Discover, value and trade antiques.", logo: "logo-antiqzy.png", image: "platform-antiqzy.png", href: "#" },
    { name: "Plantzy", group: "enthusiasts", tagline: "Know every leaf.", line: "Identify plants and learn how to care for them.", logo: "logo-plantzy.png", image: "platform-plantzy.png", href: "#" },
    { name: "Insecto", group: "enthusiasts", tagline: "A closer look at a tiny world.", line: "Identify insects and discover how they live.", logo: "logo-insecto.png", image: "platform-insecto.png", href: "#" },
    { name: "Shroomzy", group: "enthusiasts", tagline: "Step into the world of fungi.", line: "Identify mushrooms and learn all about them.", logo: "logo-shroomzy.png", image: "platform-shroomzy.png", href: "#" },
    { name: "Habiteazy", group: "more", tagline: "Small habits, big change.", line: "Build better habits, one day at a time.", logo: "logo-habiteazy.png", image: "platform-habiteazy.png", href: "#" }
  ],

  steps: [
    { title: "Identify", text: "Point your camera at an item. Our AI tells you what it is in seconds.", image: "step-identify.png" },
    { title: "Learn", text: "See its history, rarity and estimated value, from a catalogue of hundreds of thousands of items.", image: "step-learn.png" },
    { title: "Collect", text: "Save what you own, track its value and build your digital collection.", image: "step-collect.png" },
    { title: "Ask an expert", text: "Get a second opinion from real experts on our panel.", image: "step-expert.png" },
    { title: "Trade", text: "Buy and sell with other collectors and trusted dealers on our marketplace.", image: "step-trade.png" }
  ],

  marketplace: {
    title: "A marketplace for collectors and trusted dealers",
    text: "Buy and sell with people who share your passion. Dealers can list their items for free and reach collectors near them.",
    points: ["Free to list", "Verified dealer badges, coming soon", "Web version, coming soon"],
    image: "marketplace.png",
    cta: { label: "Explore the marketplace", href: "https://trackzio.com/coinzy" }
  },

  // Placeholders. Fill in from the "Our Experts" section doc once each expert has given consent.
  experts: [
    { name: "Expert name", country: "South Africa", focus: "South African and world coins", photo: "expert-1.png" },
    { name: "Expert name", country: "United Kingdom", focus: "British and ancient coins", photo: "expert-2.png" },
    { name: "Expert name", country: "India", focus: "Indian coins and banknotes", photo: "expert-3.png" },
    { name: "Expert name", country: "India", focus: "Error notes and banknotes", photo: "expert-4.png" },
    { name: "Expert name", country: "India", focus: "Gold and silver", photo: "expert-5.png" },
    { name: "Expert name", country: "India", focus: "World coins", photo: "expert-6.png" }
  ],

  partners: {
    title: "Are you a dealer, shop or club?",
    text: "Reach collectors near you, list your items for free and get leads from local collectors who want to sell.",
    cta: { label: "Become a partner", href: "https://trackzio.com/partners" }
  },

  // SAMPLE TEXT ONLY. Replace with the real reviews from the live site before anyone outside the team sees this.
  reviews: [
    { platform: "Coinzy", name: "Sample user", stars: 5, text: "Sample review. Replace with a real Coinzy review from the live site." },
    { platform: "Coinzy", name: "Sample user", stars: 5, text: "Sample review. Replace with a real Coinzy review from the live site." },
    { platform: "Coinzy", name: "Sample user", stars: 4, text: "Sample review. Replace with a real Coinzy review from the live site." },
    { platform: "Banknote", name: "Sample user", stars: 5, text: "Sample review. Replace with a real Banknote review from the live site." },
    { platform: "Banknote", name: "Sample user", stars: 4, text: "Sample review. Replace with a real Banknote review from the live site." },
    { platform: "Rockzy", name: "Sample user", stars: 5, text: "Sample review. Replace with a real Rockzy review from the live site." },
    { platform: "Plantzy", name: "Sample user", stars: 5, text: "Sample review. Replace with a real Plantzy review from the live site." },
    { platform: "Insecto", name: "Sample user", stars: 5, text: "Sample review. Replace with a real Insecto review from the live site." },
    { platform: "Habiteazy", name: "Sample user", stars: 5, text: "Sample review. Replace with a real Habiteazy review from the live site." }
  ],

  getApp: {
    title: "Start collecting smarter",
    text: "Download our platforms on iOS and Android. Web versions coming soon.",
    appStore: "https://apps.apple.com/",
    playStore: "https://play.google.com/",
    qr: "qr-code.png"
  }
};
