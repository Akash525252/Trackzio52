/* Builds the page from window.SITE (assets/js/data.js). */
(function () {
  const S = window.SITE;
  const $ = (sel) => document.querySelector(sel);
  const IMG = (file) => "assets/images/" + file;

  // Image with a labelled placeholder if the file isn't uploaded yet
  function img(file, alt, cls) {
    return `<img src="${IMG(file)}" alt="${alt || ""}" class="${cls || ""}" data-ph="${file}" loading="lazy" />`;
  }
  function wirePlaceholders(root) {
    (root || document).querySelectorAll("img[data-ph]").forEach((el) => {
      if (el.dataset.wired) return;
      el.dataset.wired = "1";
      const swap = () => {
        const ph = document.createElement("div");
        ph.className = "ph " + el.className;
        ph.textContent = el.dataset.ph;
        el.replaceWith(ph);
      };
      if (el.complete && el.naturalWidth === 0) swap();
      else el.addEventListener("error", swap);
    });
  }

  /* ---------- HERO ---------- */
  $("#hero-tag").textContent = S.hero.tag;
  $("#hero-title").textContent = S.hero.titleStart;
  $("#hero-sub").textContent = S.hero.subtitle;
  $("#hero-ctas").innerHTML =
    `<a class="btn" href="${S.hero.primaryCta.href}">${S.hero.primaryCta.label}</a>` +
    `<a class="btn btn--ghost" href="${S.hero.secondaryCta.href}">${S.hero.secondaryCta.label}</a>`;
  $("#hero-visual").innerHTML = S.hero.images.map((f, i) => img(f, "App screen " + (i + 1), "phone phone--" + i)).join("");

  let w = 0;
  const wordEl = $("#hero-word");
  wordEl.textContent = S.hero.rotatingWords[0];
  setInterval(() => {
    w = (w + 1) % S.hero.rotatingWords.length;
    wordEl.classList.remove("in");
    void wordEl.offsetWidth;
    wordEl.textContent = S.hero.rotatingWords[w];
    wordEl.classList.add("in");
  }, 2200);

  /* ---------- STATS (count up when visible) ---------- */
  $("#stats").innerHTML = S.stats
    .map((s, i) => `<div class="stat"><strong data-i="${i}">0${s.suffix}</strong><span>${s.label}</span></div>`)
    .join("");
  const statObs = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (!e.isIntersecting) return;
      const s = S.stats[e.target.dataset.i];
      const start = performance.now();
      const dur = 1200;
      const tick = (t) => {
        const p = Math.min((t - start) / dur, 1);
        const v = s.value * (1 - Math.pow(1 - p, 3));
        const shown = s.decimals ? v.toFixed(s.decimals) : Math.round(v).toLocaleString();
        e.target.textContent = shown + s.suffix;
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      statObs.unobserve(e.target);
    });
  }, { threshold: 0.5 });
  document.querySelectorAll(".stat strong").forEach((el) => statObs.observe(el));

  /* ---------- PLATFORMS (filter tabs) ---------- */
  const groups = [
    { key: "all", label: "All" },
    { key: "collectors", label: "For collectors" },
    { key: "enthusiasts", label: "For enthusiasts" },
    { key: "more", label: "More from Trackzio" }
  ];
  function renderPlatforms(key) {
    const list = S.platforms.filter((p) => key === "all" || p.group === key);
    $("#platform-grid").innerHTML = list
      .map(
        (p) => `<a class="pcard pcard--${p.group}" href="${p.href}">
          <div class="pcard__img">${img(p.image, p.name)}</div>
          <div class="pcard__body">
            <div class="pcard__head">${img(p.logo, p.name + " logo", "pcard__logo")}<span>${p.name}</span></div>
            <h3>${p.tagline}</h3>
            <p>${p.line}</p>
            <span class="pcard__link">Explore ${p.name} →</span>
          </div>
        </a>`
      )
      .join("");
    wirePlaceholders($("#platform-grid"));
  }
  makeTabs("#platform-tabs", groups, renderPlatforms);

  /* ---------- HOW IT WORKS (click a step) ---------- */
  $("#how-steps").innerHTML = S.steps
    .map((s, i) => `<li><button data-i="${i}"><span class="num">${i + 1}</span>${s.title}</button></li>`)
    .join("");
  function showStep(i) {
    const s = S.steps[i];
    document.querySelectorAll("#how-steps button").forEach((b) => b.classList.toggle("active", +b.dataset.i === i));
    $("#how-panel").innerHTML = `<div class="how__img">${img(s.image, s.title)}</div><h3>${s.title}</h3><p>${s.text}</p>`;
    wirePlaceholders($("#how-panel"));
  }
  let step = 0;
  let stepTimer = setInterval(() => showStep((step = (step + 1) % S.steps.length)), 4000);
  $("#how-steps").addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    clearInterval(stepTimer);
    showStep((step = +b.dataset.i));
  });
  showStep(0);

  /* ---------- MARKETPLACE ---------- */
  const m = S.marketplace;
  $("#marketplace-inner").innerHTML = `
    <div>
      <span class="eyebrow">Marketplace</span>
      <h2>${m.title}</h2>
      <p class="lead">${m.text}</p>
      <ul class="checks">${m.points.map((p) => `<li>${p}</li>`).join("")}</ul>
      <a class="btn" href="${m.cta.href}">${m.cta.label}</a>
    </div>
    <div class="split__img">${img(m.image, "Marketplace")}</div>`;

  /* ---------- EXPERTS (scrolling cards) ---------- */
  $("#experts-track").innerHTML = S.experts
    .map(
      (x) => `<div class="expert">${img(x.photo, x.name, "expert__photo")}
        <h4>${x.name}</h4><span class="expert__country">${x.country}</span><p>${x.focus}</p></div>`
    )
    .join("");
  document.querySelectorAll(".carousel__btn").forEach((b) =>
    b.addEventListener("click", () => {
      $("#experts-track").scrollBy({ left: +b.dataset.dir * 280, behavior: "smooth" });
    })
  );

  /* ---------- PARTNERS ---------- */
  const pa = S.partners;
  $("#partner-band").innerHTML = `<div><h2>${pa.title}</h2><p>${pa.text}</p></div>
    <a class="btn btn--light" href="${pa.cta.href}">${pa.cta.label}</a>`;

  /* ---------- REVIEWS (tabs per platform + show more) ---------- */
  const reviewPlatforms = ["All", ...new Set(S.reviews.map((r) => r.platform))];
  let reviewKey = "All";
  let reviewLimit = 6;
  function renderReviews(key) {
    if (key !== reviewKey) reviewLimit = 6;
    reviewKey = key;
    const list = S.reviews.filter((r) => key === "All" || r.platform === key);
    $("#review-grid").innerHTML = list
      .slice(0, reviewLimit)
      .map(
        (r) => `<div class="review"><div class="review__stars">${"★".repeat(r.stars)}${"☆".repeat(5 - r.stars)}</div>
          <p>${r.text}</p><div class="review__by"><strong>${r.name}</strong><span>${r.platform}</span></div></div>`
      )
      .join("");
    $("#review-more").style.display = list.length > reviewLimit ? "" : "none";
  }
  makeTabs("#review-tabs", reviewPlatforms.map((p) => ({ key: p, label: p })), renderReviews);
  $("#review-more").addEventListener("click", () => {
    reviewLimit += 6;
    renderReviews(reviewKey);
  });

  /* ---------- GET THE APP ---------- */
  const g = S.getApp;
  $("#getapp").innerHTML = `
    <div><h2>${g.title}</h2><p class="lead">${g.text}</p>
      <div class="stores">
        <a href="${g.appStore}">${img("badge-app-store.png", "Download on the App Store", "store")}</a>
        <a href="${g.playStore}">${img("badge-google-play.png", "Get it on Google Play", "store")}</a>
      </div></div>
    <div class="getapp__qr">${img(g.qr, "QR code")}<span>Scan to download</span></div>`;

  /* ---------- SHARED ---------- */
  function makeTabs(sel, items, onSelect) {
    const el = $(sel);
    el.innerHTML = items.map((t, i) => `<button class="${i === 0 ? "active" : ""}" data-key="${t.key}">${t.label}</button>`).join("");
    el.addEventListener("click", (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      el.querySelectorAll("button").forEach((x) => x.classList.toggle("active", x === b));
      onSelect(b.dataset.key);
    });
    onSelect(items[0].key);
  }

  const toggle = $(".nav__toggle");
  toggle.addEventListener("click", () => {
    const open = document.body.classList.toggle("menu-open");
    toggle.setAttribute("aria-expanded", open);
  });
  document.querySelectorAll(".nav__links a").forEach((a) => a.addEventListener("click", () => document.body.classList.remove("menu-open")));

  $("#year").textContent = new Date().getFullYear();
  wirePlaceholders();
})();
