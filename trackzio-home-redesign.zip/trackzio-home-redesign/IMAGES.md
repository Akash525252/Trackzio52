# Images to create

Put every image in `assets/images/` using **exactly** the file name below.
Until a file is uploaded, the page shows a grey placeholder with the file name, so you can see where each image goes.

Tip for AI images: add "clean, modern, soft natural light, no text, no logos" to each prompt. Use real screenshots for app screens where possible.

## Logos (use the real ones from the team)

| File | Size | What it is |
|---|---|---|
| trackzio-logo.png | 260 × 68, transparent | Trackzio logo for the top bar |
| trackzio-logo-white.png | 260 × 68, transparent | White version for the footer |
| logo-coinzy.png … logo-habiteazy.png | 128 × 128 | App icons: coinzy, banknote, rockzy, antiqzy, plantzy, insecto, shroomzy, habiteazy |
| badge-app-store.png | 320 × 96 | Official "Download on the App Store" badge |
| badge-google-play.png | 320 × 96 | Official "Get it on Google Play" badge |
| qr-code.png | 260 × 260 | QR code to the download page |

## Hero (phone screens)

| File | Size | Prompt / source |
|---|---|---|
| hero-phone-1.png | 400 × 800 | Real Coinzy screenshot: scan result for a coin |
| hero-phone-2.png | 400 × 800 | Real Rockzy screenshot: identified mineral |
| hero-phone-3.png | 400 × 800 | Real Banknote or marketplace screenshot |

## Platform cards

| File | Size | Prompt |
|---|---|---|
| platform-coinzy.png | 800 × 500 | Close-up of old silver and copper coins on a dark wooden table, warm light |
| platform-banknote.png | 800 × 500 | Vintage banknotes from different countries fanned out on a desk |
| platform-rockzy.png | 800 × 500 | Colourful crystals and minerals (amethyst, quartz) on a stone surface |
| platform-antiqzy.png | 800 × 500 | Antique pocket watch, old camera and vase on a wooden shelf |
| platform-plantzy.png | 800 × 500 | Fresh green houseplant leaves in soft daylight |
| platform-insecto.png | 800 × 500 | Macro photo of a colourful beetle on a leaf |
| platform-shroomzy.png | 800 × 500 | Wild mushrooms growing on a mossy forest floor |
| platform-habiteazy.png | 800 × 500 | Minimal desk with a phone showing a habit checklist, morning light |

## How it works

| File | Size | Prompt |
|---|---|---|
| step-identify.png | 1200 × 560 | Hand holding a phone, camera pointed at a coin |
| step-learn.png | 1200 × 560 | Phone screen showing a coin's details and history (real screenshot preferred) |
| step-collect.png | 1200 × 560 | Phone showing a grid of saved coins (real screenshot preferred) |
| step-expert.png | 1200 × 560 | Expert with a magnifying loupe examining a coin |
| step-trade.png | 1200 × 560 | Two people's hands exchanging a coin across a table |

## Marketplace

| File | Size | Prompt |
|---|---|---|
| marketplace.png | 1000 × 760 | Phone showing the Coinzy marketplace listing grid (real screenshot) |

## Experts

| File | Size | Source |
|---|---|---|
| expert-1.png … expert-6.png | 300 × 300, square | Real photos from each expert, **only after they've agreed**. Until then, keep the placeholders. Don't use AI-made faces with real names |
