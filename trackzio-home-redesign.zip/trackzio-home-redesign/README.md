# Trackzio home page redesign (demo)

A working demo of the new trackzio.com home page, for the team to review.
It is a plain HTML/CSS/JS site with no build step: open `index.html` in a browser and it works.

## What's on the page

1. **Hero**, about half the old height. Rotating word (coins, banknotes, rocks…), two buttons, three phone screens
2. **Stats strip** that counts up when it scrolls into view
3. **Our platforms**: cards with taglines and filter tabs (All, Collectors, Enthusiasts, More)
4. **How it works**: five steps (Identify, Learn, Collect, Ask an expert, Trade). Click a step to see it; it also auto-plays
5. **Marketplace spotlight**
6. **Our experts**: scrolling cards with arrows
7. **Partner band** for dealers, shops and clubs
8. **Reviews** with tabs per platform and "Show more"
9. **Get the app**: store badges and QR code
10. **Footer**. The disclaimer section has been removed.

## How it's built

All the text lives in **`assets/js/data.js`**. Change a tagline, add a review or add a platform there, and the page updates. You don't need to touch the HTML.

```
index.html              page layout
assets/css/style.css    design (colours are at the top)
assets/js/data.js       all content
assets/js/main.js       tabs, counters, carousel, etc.
assets/images/          your images (see IMAGES.md)
```

## Before sharing

- Reviews in `data.js` are **sample text**. Replace them with the real reviews from the live site.
- Expert names and photos are **placeholders**. Fill them in only with each expert's consent.
- App Store, Play Store and social links are placeholders.

## Put it on GitHub

1. Go to github.com → **New repository** → name it `trackzio-home-redesign` → Create.
2. Click **uploading an existing file** and drag in everything from this folder (keep the folders).
3. Commit.

To get a live link for the team:

4. Go to **Settings → Pages**, set Source to **Deploy from a branch**, Branch **main**, folder **/ (root)**, then Save.
5. After a minute, the page is live at `https://<your-username>.github.io/trackzio-home-redesign/`.

## Adding images

Create the images listed in `IMAGES.md`, then upload them into `assets/images/` on GitHub (open the folder → **Add file → Upload files**). The grey placeholders disappear as each image is added.
